package com.project.santanderbootcamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SantanderBootcampApplication {

	public static void main(String[] args) {
		SpringApplication.run(SantanderBootcampApplication.class, args);
	}

}
