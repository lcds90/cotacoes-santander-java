package com.project.santanderbootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SantanderBootcampApplicationTests {

	@Test
	void contextLoads() {
	}

}
